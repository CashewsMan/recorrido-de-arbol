package recorrido;

import java.util.Scanner;

public class TreePath {
	public static void main (String [] args) {
		new TreePath();
	}
	public TreePath(){
		read();
	}
	private void read() {
		System.out.println("escriva una ecuacion");
		Scanner scanner=new Scanner(System.in);
		String ecuation;
		boolean end=false;
		do {
			try {
				ecuation=scanner.nextLine();
				calculatePaths(ecuation);
				end=true;
			}
			catch(Exception e){
				System.out.println("ecuacion incorrecta");
				System.out.println("escriva una ecuacion correcta");
				scanner=new Scanner(System.in);
			}
		}while(end==false);
		scanner.close();
	}
	private void calculatePaths (String ecuation){
		calculate(ecuation);
		System.out.println("preorder");
		preorderCalculate(ecuation);
		System.out.println("");
		System.out.println("inorder");
		inorderCalculate(ecuation);
		System.out.println("");
		System.out.println("postorder");
		postorderCalculate(ecuation);
		System.out.println("");
	}
	private double calculate(String ecuation){
		if(ecuation.contains("+")){
			return sum(ecuation);
		}
		if(ecuation.contains("-")){
			return res(ecuation);
		}
		if(ecuation.contains("*")){
			return mul(ecuation);
		}
		if(ecuation.contains("/")){
			return div(ecuation);
		}
		return Float.parseFloat(ecuation);
	}
	private double sum(String ecuation) {
		return calculate(ecuation.substring(0,ecuation.split("\\+")[0].length()))+calculate(ecuation.substring(ecuation.split("\\+")[0].length()+1));
	}
	private double res(String ecuation) {
		return calculate(ecuation.substring(0,ecuation.split("\\-")[0].length()))-calculate(ecuation.substring(ecuation.split("\\-")[0].length()+1));
	}
	private double mul(String ecuation) {
		return calculate(ecuation.substring(0,ecuation.split("\\*")[0].length()))*calculate(ecuation.substring(ecuation.split("\\*")[0].length()+1));
	}
	private double div(String ecuation) {
		return calculate(ecuation.substring(0,ecuation.split("\\/")[0].length()))/calculate(ecuation.substring(ecuation.split("\\/")[0].length()+1));
	}
	private double preorderCalculate(String ecuation){
		if(ecuation.contains("+")){
			return preorderSum(ecuation);
		}
		if(ecuation.contains("-")){
			return preorderRes(ecuation);
		}
		if(ecuation.contains("*")){
			return preorderMul(ecuation);
		}
		if(ecuation.contains("/")){
			return preorderDiv(ecuation);
		}
		System.out.print(ecuation+" ");
		return Float.parseFloat(ecuation);
	}
	private double preorderSum(String ecuation) {
		System.out.print("+ ");
		return preorderCalculate(ecuation.substring(0,ecuation.split("\\+")[0].length()))+preorderCalculate(ecuation.substring(ecuation.split("\\+")[0].length()+1));
	}
	private double preorderRes(String ecuation) {
		System.out.print("- ");
		return preorderCalculate(ecuation.substring(0,ecuation.split("\\-")[0].length()))-preorderCalculate(ecuation.substring(ecuation.split("\\-")[0].length()+1));
	}
	private double preorderMul(String ecuation) {
		System.out.print("* ");
		return preorderCalculate(ecuation.substring(0,ecuation.split("\\*")[0].length()))*preorderCalculate(ecuation.substring(ecuation.split("\\*")[0].length()+1));
	}
	private double preorderDiv(String ecuation) {
		System.out.print("/ ");
		return preorderCalculate(ecuation.substring(0,ecuation.split("\\/")[0].length()))/preorderCalculate(ecuation.substring(ecuation.split("\\/")[0].length()+1));
	}
	private double inorderCalculate(String ecuation){
		if(ecuation.contains("+")){
			return inorderSum(ecuation);
		}
		if(ecuation.contains("-")){
			return inorderRes(ecuation);
		}
		if(ecuation.contains("*")){
			return inorderMul(ecuation);
		}
		if(ecuation.contains("/")){
			return inorderDiv(ecuation);
		}
		System.out.print(ecuation+" ");
		return Float.parseFloat(ecuation);
	}
	private double inorderSum(String ecuation) {
		double i;
		i=inorderCalculate(ecuation.substring(0,ecuation.split("\\+")[0].length()));
		System.out.print("+ ");
		return i+inorderCalculate(ecuation.substring(ecuation.split("\\+")[0].length()+1));
	}
	private double inorderRes(String ecuation) {
		double i;
		i=inorderCalculate(ecuation.substring(0,ecuation.split("\\-")[0].length()));
		System.out.print("- ");
		return i-inorderCalculate(ecuation.substring(ecuation.split("\\-")[0].length()+1));
	}
	private double inorderMul(String ecuation) {
		double i;
		i=inorderCalculate(ecuation.substring(0,ecuation.split("\\*")[0].length()));
		System.out.print("* ");
		return i*inorderCalculate(ecuation.substring(ecuation.split("\\*")[0].length()+1));
	}
	private double inorderDiv(String ecuation) {
		double i;
		i=inorderCalculate(ecuation.substring(0,ecuation.split("\\/")[0].length()));
		System.out.print("/ ");
		return i/inorderCalculate(ecuation.substring(ecuation.split("\\/")[0].length()+1));
	}
	private double postorderCalculate(String ecuation){
		double i;
		if(ecuation.contains("+")){
			i=postorderSum(ecuation);
			System.out.print("+ ");
			return i;
		}
		if(ecuation.contains("-")){
			i=postorderRes(ecuation);
			System.out.print("- ");
			return i;
		}
		if(ecuation.contains("*")){
			i=postorderMul(ecuation);
			System.out.print("* ");
			return i;
		}
		if(ecuation.contains("/")){
			i=postorderDiv(ecuation);
			System.out.print("/ ");
			return i;
		}
		System.out.print(ecuation+" ");
		return Float.parseFloat(ecuation);
	}
	private double postorderSum(String ecuation) {
		return postorderCalculate(ecuation.substring(0,ecuation.split("\\+")[0].length()))+postorderCalculate(ecuation.substring(ecuation.split("\\+")[0].length()+1));
	}
	private double postorderRes(String ecuation) {
		return postorderCalculate(ecuation.substring(0,ecuation.split("\\-")[0].length()))-postorderCalculate(ecuation.substring(ecuation.split("\\-")[0].length()+1));
	}
	private double postorderMul(String ecuation) {
		return postorderCalculate(ecuation.substring(0,ecuation.split("\\*")[0].length()))*postorderCalculate(ecuation.substring(ecuation.split("\\*")[0].length()+1));
	}
	private double postorderDiv(String ecuation) {
		return postorderCalculate(ecuation.substring(0,ecuation.split("\\/")[0].length()))/postorderCalculate(ecuation.substring(ecuation.split("\\/")[0].length()+1));
	}
}